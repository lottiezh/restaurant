import Vue from 'vue'
import App from './App.vue'
import QuantityCounter from './QuantityCounter.vue'
import PageContent from './PageContent.vue'
import Basket from './Basket.vue'


Vue.config.productionTip = false
Vue.component('qtyCounter', QuantityCounter)
Vue.component('pageContent', PageContent)
Vue.component('Basket', Basket)

new Vue({
  render: h => h(App),
}).$mount('#app')

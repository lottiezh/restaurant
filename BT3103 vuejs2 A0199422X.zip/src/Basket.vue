<template>
    <div>
        <p>Menu:</p>
        <ul id="list">
            <li id="list" v-for="item in itemsSelected" v-bind:key="item.id">
                <p>{{item[0]}} x {{item[1]}}</p>
            </li>
        </ul>
        <br>
        <button @click="findTotal"> Calculate Total </button>
        <p v-show="show"> Subtotal: ${{subtotal}} <br> Grand Total: ${{grandtotal}} </p>
        
    </div>
</template>

<script>
    export default {
        props: {
            itemsSelected: {
                type: String
            }
        },
        data() {
            return {
                subtotal: 0,
                show: false,
            }
        },
        computed: {
            grandtotal: function() {
                var rounding = this.subtotal * 1.07;
                return rounding.toFixed(2);
            }
        },
        methods: {
            findTotal() {
                this.show = true;
                var sub = 0;
                for (var i = 0; i < this.itemsSelected.length; i++) {
                    sub += this.itemsSelected[i][2] * this.itemsSelected[i][1];
                }
                this.subtotal = sub;
            }
        }
    }
</script>

<style>
p {
    font-size: 24px;
    font-weight: bold;
}
</style>
